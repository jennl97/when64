//: Playground - noun: a place where people can play

import UIKit

class Age {
    var yearBorn: Int = 0
    let sixtyFour: Int = 64
    
    init (yearBorn: Int) {
        self.yearBorn = yearBorn
    }
}

let jenn = Age(yearBorn:1900)

//print(jenn.yearBorn)
print ("You will be 64 in the year", jenn.yearBorn + jenn.sixtyFour)
